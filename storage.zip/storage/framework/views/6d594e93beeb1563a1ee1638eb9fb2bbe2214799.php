<?php if(session('success')): ?>
    <div class="alert alert-green">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/errors/success.blade.php ENDPATH**/ ?>