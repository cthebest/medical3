<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Crear ítem de menú'); ?>
    <div>
        <div class="card">

            <div class="flex justify-between">
                <h2 class="mb-5">Ítems de menú</h2>
                <div>
                    <span class="error">*</span>
                    <span class="dark:text-gray-200"> = requerido</span>
                </div>
            </div>


            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('menuitem::menu-item-form')->html();
} elseif ($_instance->childHasBeenRendered('STgWw5w')) {
    $componentId = $_instance->getRenderedChildComponentId('STgWw5w');
    $componentTag = $_instance->getRenderedChildComponentTagName('STgWw5w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('STgWw5w');
} else {
    $response = \Livewire\Livewire::mount('menuitem::menu-item-form');
    $html = $response->html();
    $_instance->logRenderedChild('STgWw5w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php echo $__env->make('errors.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/Modules/MenuItem/Resources/views/create.blade.php ENDPATH**/ ?>