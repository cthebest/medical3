<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'label' => '',
    'icon' => '',
    'route' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'label' => '',
    'icon' => '',
    'route' => ''
]); ?>
<?php foreach (array_filter(([
    'label' => '',
    'icon' => '',
    'route' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$openState = Route::is($route.'*') ? '{ isOpen: true }' : '{ isOpen: false }';
?>

<div class="block" x-data="<?php echo e($openState); ?>">
    <div @click="isOpen = !isOpen" class="flex items-center justify-between px-2 py-2 text-gray-100 hover:bg-gray-100 hover:text-gray-900 cursor-pointer rounded-md">
        <div>
            <?php if($icon): ?>
                <i class="<?php echo e($icon); ?> pr-1"></i>
            <?php endif; ?>
            <span><?php echo e($label); ?></span>
        </div>

        <svg x-show="isOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"></path></svg>
        <svg x-show="!isOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
    </div>
    <div x-show="isOpen" class="text-sm">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH /var/www/html/resources/views/components/nav/group.blade.php ENDPATH**/ ?>