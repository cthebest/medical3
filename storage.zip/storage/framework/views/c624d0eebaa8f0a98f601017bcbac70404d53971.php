<div class="bg-gray-200 dark:bg-gray-700 dark:text-white min-h-screen bg-gray-50 dark:bg-gray-700 flex flex-col sm:justify-center items-center pt-6 sm:pt-0">
    <section class="hero container max-w-screen-lg mx-auto text-center">
        <?php
            //cache the logo setting to reduce calling the database
            $loginLogo = Cache::rememberForever('loginLogo', function () {
                return \App\Models\Setting::where('key', 'loginLogo')->value('value');
            });

            $loginLogoDark = Cache::rememberForever('loginLogoDark', function () {
                return \App\Models\Setting::where('key', 'loginLogoDark')->value('value');
            });
        ?>

        <a href="<?php echo e(url('admin')); ?>">
            <?php if(storage_exists($loginLogo)): ?>
                <picture>
                    <source srcset="<?php echo e(Storage::url($loginLogoDark)); ?>" media="(prefers-color-scheme: dark)">
                    <img class="mx-auto" src="<?php echo e(Storage::url($loginLogo)); ?>" alt="<?php echo e(config('app.name')); ?>">
                </picture>
            <?php else: ?>
                <h1><?php echo e(config('app.name')); ?></h1>
            <?php endif; ?>
        </a>
    </section>

    <div class="w-full sm:max-w-md mt-6 mb-10 px-6 py-4 bg-white dark:bg-gray-900 shadow-md overflow-hidden sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/auth-card.blade.php ENDPATH**/ ?>