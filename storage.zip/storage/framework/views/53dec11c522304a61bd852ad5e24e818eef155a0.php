<div>
    <?php if($services->count() > 0): ?>
        <section>
            <div class="container mx-auto space-y-4 py-10">
                <h1 class="text-[#006699] text-4xl">¡Acércate a nosotros para informarte, descubrir un posible
                    trastorno o problema neurólogico, es importante realizar un estudio a fondo!</h1>

                <div class="grid md:grid-cols-2 lg:grid-cols-3 sm:grid-cols-1 py-10 gap-2">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.posttemplate','data' => ['title' => ''.e(str_limit($service->title, 100)).'','description' => ''.e(str_limit($service->description, 120)).'','date' => ''.e($service->created_at->formatLocalized('%d de %B %Y')).'','imageClass' => '','publicationUrl' => ''.e($service->article_url).'','image' => ''.e($service->image).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('posttemplate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(str_limit($service->title, 100)).'','description' => ''.e(str_limit($service->description, 120)).'','date' => ''.e($service->created_at->formatLocalized('%d de %B %Y')).'','image_class' => '','publication_url' => ''.e($service->article_url).'','image' => ''.e($service->image).'']); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/Modules/Service/Resources/views/livewire/index-service.blade.php ENDPATH**/ ?>