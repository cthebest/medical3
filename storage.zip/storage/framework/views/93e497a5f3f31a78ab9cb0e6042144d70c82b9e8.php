<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'method' => 'post'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'method' => 'post'
]); ?>
<?php foreach (array_filter(([
    'method' => 'post'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$method = strtolower($method);
?>

<form method="<?php echo e($method === 'get' ? 'get' : 'post'); ?>" <?php echo e($attributes); ?>>
<?php if($method != 'get'): ?>
    <?php echo csrf_field(); ?>
<?php endif; ?>

<?php if(! in_array(strtolower($method), ['get', 'post'])): ?>
    <?php echo method_field($method); ?>
<?php endif; ?>

<?php echo e($slot); ?>


</form><?php /**PATH /var/www/html/resources/views/components/form.blade.php ENDPATH**/ ?>