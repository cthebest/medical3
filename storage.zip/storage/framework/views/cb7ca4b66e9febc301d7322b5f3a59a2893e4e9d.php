<?php $__env->startComponent('mail::message'); ?>

<h1>Hola <?php echo e($user->name); ?></h1>

<p><?php echo e($user->invite->name); ?> has sido invitado a unirte a <?php echo e(config('config.name')); ?></p>

<?php $__env->startComponent('mail::button', ['url' => url("join/$user->invite_token")]); ?>
    unirse <?php echo e(config('config.name')); ?>

<?php echo $__env->renderComponent(); ?>

<p>Gracias, <?php echo e(config('config.name')); ?></p>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/resources/views/mail/users/invite.blade.php ENDPATH**/ ?>