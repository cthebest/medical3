<layouts-web>
    <?php $__env->startSection('content'); ?>
        <div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('service::index-service', [])->html();
} elseif ($_instance->childHasBeenRendered('l1260623518-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1260623518-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1260623518-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1260623518-0');
} else {
    $response = \Livewire\Livewire::mount('service::index-service', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1260623518-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('article::index-articles', [])->html();
} elseif ($_instance->childHasBeenRendered('l1260623518-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1260623518-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1260623518-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1260623518-1');
} else {
    $response = \Livewire\Livewire::mount('article::index-articles', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1260623518-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


            <section class="space-y-4">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d120689.12363162886!2d-98.26300596649035!3d19.04019627469931!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sco!4v1673910984785!5m2!1ses-419!2sco"
                    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" class="w-full"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </section>
        </div>
    <?php $__env->stopSection(); ?>
</layouts-web>
<?php /**PATH /var/www/html/resources/views/livewire/welcome.blade.php ENDPATH**/ ?>