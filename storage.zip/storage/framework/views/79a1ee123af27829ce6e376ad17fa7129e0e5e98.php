<div>
    <section>
        <div class="container mx-auto py-10 space-y-4">
            <h1 class="text-[#006699] text-4xl">Nuestras últimas publicaciones</h1>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.posttemplate','data' => ['title' => ''.e(str_limit($article->title, 100)).'','description' => ''.e(str_limit($article->body, 120)).'','date' => ''.e($article->created_at->formatLocalized('%d de %B %Y')).'','publicationUrl' => ''.e($article->url).'','image' => ''.e($article->image).'','imageClass' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('posttemplate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(str_limit($article->title, 100)).'','description' => ''.e(str_limit($article->body, 120)).'','date' => ''.e($article->created_at->formatLocalized('%d de %B %Y')).'','publication_url' => ''.e($article->url).'','image' => ''.e($article->image).'','image_class' => 'w-full']); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /var/www/html/Modules/Article/Resources/views/livewire/index-articles.blade.php ENDPATH**/ ?>