<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(session('message')): ?>
    <div class="">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-green">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('status')): ?>
    <div class="alert alert-primary">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/errors/messages.blade.php ENDPATH**/ ?>