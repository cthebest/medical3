<?php echo e($request->message); ?>

<?php /**PATH /var/www/html/resources/views/emails/contactus/sended.blade.php ENDPATH**/ ?>