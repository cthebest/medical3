<?php $__env->startSection('title', 'Dashboard'); ?>

<h1>Dashboard</h1>

<div class="card">
    En construcción
</div>
<?php /**PATH /var/www/html/resources/views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>