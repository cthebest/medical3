<?php $__env->startSection('title', 'Roles'); ?>
<div>
    <div class="flex justify-between">

        <h1>Roles</h1>

        <div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.roles.create', [])->html();
} elseif ($_instance->childHasBeenRendered('l1070122316-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1070122316-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1070122316-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1070122316-0');
} else {
    $response = \Livewire\Livewire::mount('admin.roles.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1070122316-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>

    <?php echo $__env->make('errors.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="bg-primary text-gray-200 py-2 px-4 my-5 rounded-md">
        By default only Admin roles have permissions, additional roles will need permissions applying to them by editing the roles below.
    </div>

    <div class="grid sm:grid-cols-1 md:grid-cols-4 gap-4">

        <div class="col-span-2">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'search','id' => 'roles','name' => 'query','wire:model' => 'query','label' => 'none','placeholder' => 'Search Roles']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'search','id' => 'roles','name' => 'query','wire:model' => 'query','label' => 'none','placeholder' => 'Search Roles']); ?>
                <?php echo e(old('query', request('query'))); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

    </div>

    <table>
        <thead>
        <tr>
            <th>
                <a href="#" wire:click.prevent="sortBy('name')">Name</a>
            </th>
            <th>
                Action
            </th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $this->roles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($role->label); ?></td>
                <td>
                    <div class="flex space-x-2">

                        <a href="<?php echo e(route('admin.settings.roles.edit', ['role' => $role->id])); ?>">Edit</a>

                        <?php if($role->label == 'App'): ?>

                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php $__env->slot('trigger', null, []); ?> 
                                    <a href="#" @click="on = true">Delete</a>
                                 <?php $__env->endSlot(); ?>

                                 <?php $__env->slot('title', null, []); ?> Confirm Delete <?php $__env->endSlot(); ?>

                                 <?php $__env->slot('content', null, []); ?> 
                                    <div class="text-center">
                                        Are you sure you want to role: <b><?php echo e($role->name); ?></b>
                                    </div>
                                 <?php $__env->endSlot(); ?>

                                 <?php $__env->slot('footer', null, []); ?> 
                                    <button class="btn" @click="on = false">Cancel</button>
                                    <button class="btn btn-red" wire:click="deleteRole('<?php echo e($role->id); ?>')">Delete Role</button>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($this->roles()->links()); ?>


</div>
<?php /**PATH /var/www/html/resources/views/livewire/admin/roles/index.blade.php ENDPATH**/ ?>