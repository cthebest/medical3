<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name'  => '',
    'id'    => '',
    'label' => '',
    'value' => '',
    'selected' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name'  => '',
    'id'    => '',
    'label' => '',
    'value' => '',
    'selected' => ''
]); ?>
<?php foreach (array_filter(([
    'name'  => '',
    'id'    => '',
    'label' => '',
    'value' => '',
    'selected' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
if ($id === '') {
    $id = $name;
}
?>

<?php if($label === ''): ?>
    <?php
        //remove underscores from name
        $label = str_replace('_', ' ', $name);
        //detect subsequent letters starting with a capital
        $label = preg_split('/(?=[A-Z])/', $label);
        //display capital words with a space
        $label = implode(' ', $label);
        //uppercase first letter and lower the rest of a word
        $label = ucwords(strtolower($label));
    ?>
<?php endif; ?>

<div>
    <input type='checkbox' name='<?php echo e($name); ?>' id='<?php echo e($id); ?>' value='<?php echo e($value); ?>' <?php if($selected === $value): ?> checked='checked' <?php endif; ?> <?php echo e($attributes); ?>>
    <label for='<?php echo e($id); ?>'><?php echo e($label); ?></label>
</div>
<?php /**PATH /var/www/html/resources/views/components/form/checkbox.blade.php ENDPATH**/ ?>