<div>
    <div class="mb-4">
        <label for="module_id" class="block text-sm font-medium leading-5 text-gray-700 dark:text-gray-200">
            Módulos
        </label>

        <select name="module_id" id="module_id" wire:model='module_id' wire:change="loadResources"
            class="border border-gray-300 dark:bg-gray-500 dark:text-gray-200 p-1 w-full rounded">
            <option value="">-- Seleccione un módulo --</option>
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($module->id); ?>"><?php echo e($module->label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <?php if($table): ?>
        <div class="w-full flex items-center" x-on:resource-updated.window="on = false">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['label' => 'Seleccione un recurso','class' => 'w-full bg-gray-200','wire:model' => 'title','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Seleccione un recurso','class' => 'w-full bg-gray-200','wire:model' => 'title','disabled' => true]); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <button type="button" class="btn btn-primary m-0" wire:click="openResourceModal">Seleccionar</button>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH /var/www/html/Modules/MenuItem/Resources/views/livewire/association.blade.php ENDPATH**/ ?>