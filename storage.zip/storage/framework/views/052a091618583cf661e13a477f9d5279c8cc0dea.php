<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['image', 'title', 'description', 'date', 'publication_url', 'image_class']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['image', 'title', 'description', 'date', 'publication_url', 'image_class']); ?>
<?php foreach (array_filter((['image', 'title', 'description', 'date', 'publication_url', 'image_class']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="bg-white rounded-lg overflow-hidden">
    <?php if($image): ?>
        <div class="flex justify-center">
            <img class="<?php echo e($image_class); ?>" src="<?php echo e(storage_url($image)); ?>" alt="Image">
        </div>
    <?php endif; ?>
    <div class="p-4">
        <h2 class="text-xl font-medium"><?php echo e($title); ?></h2>
        <p class="text-sm text-gray-400"><?php echo e($date); ?></p>
        <p class="text-base"><?php echo e($description); ?></p>

    </div>
    <div class="p-4">
        <a href="<?php echo e($publication_url); ?>" class="bg-[#006699] text-white 
    p-2 rounded-lg hover:bg-blue-600">
            Leer más
        </a>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/posttemplate.blade.php ENDPATH**/ ?>