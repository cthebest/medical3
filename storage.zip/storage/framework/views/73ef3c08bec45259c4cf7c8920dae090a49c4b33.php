<div>
    <?php if(can('add_menus')): ?>
        <a href="<?php echo e(route('menuitems.create')); ?>" class="text-white p-2 btn btn-primary mb-4">Crear menú</a>
    <?php endif; ?>
    <div class="overflow-x-scroll shadow-md mb-4">
        <table>
            <thead>
                <tr>
                    <th><a href="#" wire:click.prevent="sortBy('first_name')">Título</a></th>
                    <th><a href="#" wire:click.prevent="sortBy('email')">Alias</a></th>
                    <th><a href="#">Link</a></th>
                    <th>Asociación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="flex">

                            <div class="pl-1 pt-1"><?php echo e($menuItem->title); ?></div>
                        </td>
                        <td>
                            <div class="pl-1 pt-1"><?php echo e($menuItem->alias); ?></div>
                        </td>
                        <td>
                            <div class="pl-1 pt-1"><?php echo e($menuItem->path); ?></div>
                        </td>

                        <td>
                            <div class="pl-1 pt-1"><?php echo e(json_encode($menuItem->association)); ?></div>
                        </td>

                        <td>
                            <div class="flex space-x-2">
                                <?php if(can('edit_menus')): ?>
                                    <a href="<?php echo e(route('menuitems.edit', ['menuitem' => $menuItem->id])); ?>">Edit</a>
                                <?php endif; ?>



                                <?php if(can('delete_menus')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                         <?php $__env->slot('trigger', null, []); ?> 
                                            <a href="#" @click="on = true">Eliminar</a>
                                         <?php $__env->endSlot(); ?>

                                         <?php $__env->slot('title', null, []); ?> Confirmación <?php $__env->endSlot(); ?>

                                         <?php $__env->slot('content', null, []); ?> 
                                            <div class="text-center">
                                                Estás seguro que deseas eliminar a: <b><?php echo e($menuItem->title); ?></b>
                                            </div>
                                         <?php $__env->endSlot(); ?>

                                         <?php $__env->slot('footer', null, []); ?> 
                                            <button @click="on = false">Cancelar</button>
                                            <button class="btn btn-red"
                                                wire:click="deleteMenuItem('<?php echo e($menuItem->id); ?>')">Eliminar ítem de
                                                menú
                                            </button>
                                         <?php $__env->endSlot(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div>
        <?php echo e($menuItems->links()); ?>

    </div>

</div>
<?php /**PATH /var/www/html/Modules/MenuItem/Resources/views/livewire/table.blade.php ENDPATH**/ ?>