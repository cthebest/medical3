<div>
    <?php if($specialists && $specialists->count() > 0): ?>
        <?php echo Form::select('specialists', $specialists->pluck('name','id'), null,
                        ['placeholder'=>'--Seleccione un especialista--', 'wire:model'=>'specialist_id']); ?>

    <?php endif; ?>

    <?php if(count($days) >0): ?>
        <div class="grid grid-cols-7 gap-[1px] bg-gray-200 border">
            <?php $__currentLoopData = $weekdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="font-bold text-center p-2 bg-white">
                    <?php echo e($weekday); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="bg-white  h-32 <?php echo e($day['isToday']?'text-red-700':''); ?> <?php echo e(!$day['isDayInMonth']?'text-gray-400':''); ?>">
                    <span class="text-sm"><?php echo e($day['day']); ?></span>
                    <!--Events-->
                    <?php if(array_key_exists('events', $day)): ?>
                        <div class="p-1">
                            <ul class="text-xs rounded-md font-medium">
                                <?php $__currentLoopData = $day['events']->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <span><?php echo e($event->start_time); ?></span>
                                        <span><?php echo e($event->end_time); ?></span>
                                        <span><?php echo e($event->patient->name); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php if(($day['events']->count()-3)>0): ?>
                                <div>
                                    <span
                                        class="text-xs text-blue-700 block text-right">
                                        + <?php echo e($day['events']->count()-3); ?>

                                    </span>
                                    <span class="text-xs text-orange-500">Ver todo</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>


                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/calendar-livewire.blade.php ENDPATH**/ ?>