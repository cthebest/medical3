<?php $__env->startSection('title', 'Users'); ?>
<div>
    <div class="flex justify-between">

        <h1>Users</h1>

        <div>
            <?php if(can('add_users')): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users.invite', [])->html();
} elseif ($_instance->childHasBeenRendered('l1947278971-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1947278971-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1947278971-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1947278971-0');
} else {
    $response = \Livewire\Livewire::mount('admin.users.invite', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1947278971-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endif; ?>
        </div>

    </div>

    <div class="mt-5 mb-5 grid sm:grid-cols-1 md:grid-cols-3 gap-4">

        <div class="col-span-2">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'search','name' => 'name','wire:model' => 'name','label' => 'none','placeholder' => 'Search Users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'search','name' => 'name','wire:model' => 'name','label' => 'none','placeholder' => 'Search Users']); ?>
                <?php echo e(old('name', request('name'))); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

    </div>

    <div class="mb-5" x-data="{ isOpen: <?php if($openFilter || request('openFilter')): ?> true <?php else: ?> false <?php endif; ?> }">

        <button type="button" @click="isOpen = !isOpen" class="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs leading-4 font-medium rounded-t text-grey-700 bg-gray-200 hover:bg-grey-300 dark:bg-gray-700 dark:text-gray-200 transition ease-in-out duration-150">
            <svg class="h-5 w-5 text-gray-500 dark:text-gray-200" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
            Advanced Search
        </button>

        <button type="button" wire:click="resetFilters" @click="isOpen = false" class="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs leading-4 font-medium rounded text-grey-700 bg-gray-200 hover:bg-grey-300 dark:bg-gray-700 dark:text-gray-200 transition ease-in-out duration-150">
            <svg class="h-5 w-5 text-gray-500 dark:text-gray-200" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
            </svg>
            Reset form
        </button>

        <div
                x-show="isOpen"
                x-transition:enter="transition ease-out duration-100 transform"
                x-transition:enter-start="opacity-0 scale-95"
                x-transition:enter-end="opacity-100 scale-100"
                x-transition:leave="transition ease-in duration-75 transform"
                x-transition:leave-start="opacity-100 scale-100"
                x-transition:leave-end="opacity-0 scale-95"
                class="bg-gray-200 dark:bg-gray-700 rounded-b-md p-5"
                wire:ignore.self>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'email','id' => 'email','name' => 'email','label' => 'Email','wire:model' => 'email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'email','id' => 'email','name' => 'email','label' => 'Email','wire:model' => 'email']); ?>
                    <?php echo e(old('email', request('email'))); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.daterange','data' => ['id' => 'joined','name' => 'joined','label' => 'Joined Date Range','wire:model.lazy' => 'joined']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.daterange'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'joined','name' => 'joined','label' => 'Joined Date Range','wire:model.lazy' => 'joined']); ?>
                    <?php echo e(old('joined', request('joined'))); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            </div>
        </div>

    </div>

    <div class="overflow-x-scroll shadow-md">
        <table>
        <thead>
        <tr>
            <th><a href="#" wire:click.prevent="sortBy('first_name')">Name</a></th>
            <th><a href="#" wire:click.prevent="sortBy('email')">Email</a></th>
            <th>Joined</th>
            <th>Roles</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $this->users(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="flex">
                    <div>
                        <?php if(storage_exists($user->image)): ?>
                            <img src="<?php echo e(storage_url($user->image)); ?>" width="30" class="h-8 w-8 rounded-full">
                        <?php endif; ?>
                    </div>
                    <div class="pl-1 pt-1"><?php echo e($user->name); ?></div>
                </td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php if(! empty($user->invite_token)): ?>
                        <small class="dark:text-gray-300">Invited<br> <?php echo e(date('jS M Y H:i', strtotime($user->invited_at))); ?></small>
                    <?php else: ?>
                        <?php echo e($user->created_at !=='' ? date('jS M Y', strtotime($user->created_at)) : ''); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($role->label); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <div class="flex space-x-2">

                            <?php if(can('view_users_profiles')): ?>
                                <a href="<?php echo e(route('admin.users.show', ['user' => $user->id])); ?>">Profile</a>
                            <?php endif; ?>

                            <?php if(can('edit_users')): ?>
                                <a href="<?php echo e(route('admin.users.edit', ['user' => $user->id])); ?>">Edit</a>
                            <?php elseif(auth()->id() === $user->id && can('edit_own_account')): ?>
                                <a href="<?php echo e(route('admin.users.edit', ['user' => $user->id])); ?>">Edit</a>
                            <?php endif; ?>

                            <?php if(can('add_users')): ?>
                                <?php if(!empty($user->invite_token)): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                             <?php $__env->slot('trigger', null, []); ?> 
                                                <a href="#" @click="on = true">Resend Invite</a>
                                             <?php $__env->endSlot(); ?>

                                            <?php if($sentEmail === false): ?>
                                                 <?php $__env->slot('title', null, []); ?> Send <?php echo e($user->name); ?> another invite email. <?php $__env->endSlot(); ?>
                                                 <?php $__env->slot('content', null, []); ?>  <?php $__env->endSlot(); ?>
                                                 <?php $__env->slot('footer', null, []); ?> 
                                                    <button @click="on = false">Cancel</button>
                                                    <button class="btn btn-primary" wire:click="resendInvite('<?php echo e($user->id); ?>')">Yes, Send Email</button>
                                                 <?php $__env->endSlot(); ?>
                                            <?php else: ?>
                                                 <?php $__env->slot('title', null, []); ?> Invite email sent <?php $__env->endSlot(); ?>
                                                 <?php $__env->slot('content', null, []); ?>  <?php $__env->endSlot(); ?>
                                                 <?php $__env->slot('footer', null, []); ?> 
                                                    <button @click="on = false">Close</button>
                                                 <?php $__env->endSlot(); ?>
                                            <?php endif; ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if(can('delete_users') && auth()->id() !== $user->id): ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                     <?php $__env->slot('trigger', null, []); ?> 
                                        <a href="#" @click="on = true">Delete</a>
                                     <?php $__env->endSlot(); ?>

                                     <?php $__env->slot('title', null, []); ?> Confirm Delete <?php $__env->endSlot(); ?>

                                     <?php $__env->slot('content', null, []); ?> 
                                        <div class="text-center">
                                            Are you sure you want to delete: <b><?php echo e($user->name); ?></b>
                                        </div>
                                     <?php $__env->endSlot(); ?>

                                     <?php $__env->slot('footer', null, []); ?> 
                                        <button @click="on = false">Cancel</button>
                                        <button class="btn btn-red" wire:click="deleteUser('<?php echo e($user->id); ?>')">Delete User</button>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>

    <?php echo e($this->users()->links()); ?>


</div>
<?php /**PATH /var/www/html/resources/views/livewire/admin/users/index.blade.php ENDPATH**/ ?>