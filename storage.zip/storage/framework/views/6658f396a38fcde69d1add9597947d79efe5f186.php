<?php if(can('view_search')): ?>
<form action="#" method="get">
    <div class="text-gray-900 w-56 md:w-96 rounded-md">
        <div class="relative">
            <div class="absolute inset-y-0 left-0 flex items-center pl-2">
                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
            </div>
            <input wire:model.debounce.500ms="query" type="search" class="w-full py-2 rounded-md pl-10 bg-white dark:bg-gray-700 dark:text-gray-300 focus:outline-none" placeholder="Search">
        </div>
    </div>

    <?php if(strlen($query) > 2): ?>
        <ul class="absolute z-50 bg-white dark:bg-gray-500 dark:text-gray-200 border border-gray-300 dark:border-gray-400 w-96 rounded-md mt-2 text-gray-700 text-sm divide-y divide-gray-200">

            <?php $__currentLoopData = $searchResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="p-1">
                        <a href="<?php echo e($result['route']); ?>" class="flex items-center px-4 py-4 hover:bg-gray-200 dark:hover:bg-gray-600 transition ease-in-out duration-150"><?php echo e($result['section']); ?>: <?php echo e($result['label']); ?></a>
                    </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($searchResults) === 0): ?>
                    <li class="p-1">No results</li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>

</form>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/livewire/admin/search.blade.php ENDPATH**/ ?>