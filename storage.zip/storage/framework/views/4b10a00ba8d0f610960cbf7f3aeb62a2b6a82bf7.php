<div>
    <?php if(can('add_articles')): ?>
        <a href="<?php echo e(route('articles.create')); ?>" class="text-white p-2 btn btn-primary mb-4">Crear artículo</a>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['label' => 'Buscar','name' => 'query','wire:model.debounce.500ms' => 'query']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Buscar','name' => 'query','wire:model.debounce.500ms' => 'query']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="overflow-x-auto shadow-md mb-4">
        <table class="table-auto">
            <thead>
                <tr>
                    <th><a href="#">Título</a></th>
                    <th><a href="#">Usuario</a></th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>

                            <div class="p-2"><?php echo e($article->title); ?></div>
                        </td>

                        <td>
                            <div class="p-2"><?php echo e($article->user->name); ?></div>
                        </td>

                        <td>

                            <?php if(!$isInMenuItem): ?>
                                <div class="flex space-x-2">
                                    <?php if(can('edit_articles')): ?>
                                        <a href="<?php echo e(route('articles.edit', ['article' => $article->id])); ?>">Edit</a>
                                    <?php elseif(auth()->id() === $article->id && can('edit_own_account')): ?>
                                        <a href="<?php echo e(route('articles.edit', ['article' => $article->id])); ?>">Edit</a>
                                    <?php endif; ?>


                                    <?php if(can('delete_articles')): ?>
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                             <?php $__env->slot('trigger', null, []); ?> 
                                                <a href="#" @click="on = true">Eliminar</a>
                                             <?php $__env->endSlot(); ?>

                                             <?php $__env->slot('title', null, []); ?> Confirmación <?php $__env->endSlot(); ?>

                                             <?php $__env->slot('content', null, []); ?> 
                                                <div class="text-center">
                                                    Estás seguro que deseas eliminar el artículo:
                                                    <b><?php echo e($article->title); ?></b>
                                                </div>
                                             <?php $__env->endSlot(); ?>

                                             <?php $__env->slot('footer', null, []); ?> 
                                                <button @click="on = false">Cancelar</button>
                                                <button class="btn btn-red"
                                                    wire:click="deleteArticle('<?php echo e($article->id); ?>')">Eliminar
                                                    artículo</button>
                                             <?php $__env->endSlot(); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <button type="button" wire:click="resourceAdded(<?php echo e($article); ?>)">Añadir</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div>
        <?php echo e($articles->links()); ?>

    </div>
</div>
<?php /**PATH /var/www/html/Modules/Article/Resources/views/livewire/table.blade.php ENDPATH**/ ?>