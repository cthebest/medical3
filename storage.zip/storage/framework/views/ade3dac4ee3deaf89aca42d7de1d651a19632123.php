<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/guest.scss', 'resources/js/app.js']); ?>

    <script src="https://www.google.com/recaptcha/api.js?render=6LdyVygkAAAAANImiWdZA60--y-NzIfkF-SnhxMX"></script>
    <script>
        document.addEventListener('submit', function(e) {
            e.preventDefault();
            grecaptcha.ready(function() {
                grecaptcha.execute('6LdyVygkAAAAANImiWdZA60--y-NzIfkF-SnhxMX', {
                    action: 'submit'
                }).then(function(token) {
                    let form = e.target;
                    let input = document.createElement('input');
                    input.type='hidden';
                    input.name='g-recaptcha-response';
                    input.value=token;
                    form.appendChild(input);
                    form.submit();
                });
            });
        });
    </script>
</head>

<body class="h-screen">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('menu')->html();
} elseif ($_instance->childHasBeenRendered('eHXET9T')) {
    $componentId = $_instance->getRenderedChildComponentId('eHXET9T');
    $componentTag = $_instance->getRenderedChildComponentTagName('eHXET9T');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eHXET9T');
} else {
    $response = \Livewire\Livewire::mount('menu');
    $html = $response->html();
    $_instance->logRenderedChild('eHXET9T', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <div class="font-sans">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('Eo3THf6')) {
    $componentId = $_instance->getRenderedChildComponentId('Eo3THf6');
    $componentTag = $_instance->getRenderedChildComponentTagName('Eo3THf6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Eo3THf6');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('Eo3THf6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/web.blade.php ENDPATH**/ ?>