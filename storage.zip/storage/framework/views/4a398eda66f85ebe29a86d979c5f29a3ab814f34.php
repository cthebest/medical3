<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'required' => '',
    'type' => 'text',
    'name' => '',
    'label' => '',
    'value' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'required' => '',
    'type' => 'text',
    'name' => '',
    'label' => '',
    'value' => '',
]); ?>
<?php foreach (array_filter(([
    'required' => '',
    'type' => 'text',
    'name' => '',
    'label' => '',
    'value' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($label === 'none'): ?>

<?php elseif($label === ''): ?>
    <?php
        //remove underscores from name
        $label = str_replace('_', ' ', $name);
        //detect subsequent letters starting with a capital
        $label = preg_split('/(?=[A-Z])/', $label);
        //display capital words with a space
        $label = implode(' ', $label);
        //uppercase first letter and lower the rest of a word
        $label = ucwords(strtolower($label));
    ?>
<?php endif; ?>

<div class="mb-5">
    <?php if($label !='none'): ?>
        <label for="<?php echo e($name); ?>" class="block text-sm font-medium leading-5 text-gray-700 dark:text-gray-200"><?php echo e($label); ?> <?php if($required != ''): ?> <span class="text-red-600">*</span><?php endif; ?></label>
    <?php endif; ?>
    <div class="rounded-md shadow-sm">
        <input
            type="<?php echo e($type); ?>"
            id="<?php echo e($name); ?>"
            name="<?php echo e($name); ?>"
            value="<?php echo e($slot); ?>"
            <?php echo e($required); ?>

            <?php echo e($attributes->merge(['class' => 'block w-full dark:bg-gray-500 dark:text-gray-200 dark:placeholder-gray-200 border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-light-blue-500 focus:border-light-blue-500 sm:text-sm'])); ?>>
        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<?php /**PATH /var/www/html/resources/views/components/form/input.blade.php ENDPATH**/ ?>